System.register([],function(e,t){"use strict";return{execute:function(){e("_","/assets/logo-rsud-D8dyLFCY.png")}}});
