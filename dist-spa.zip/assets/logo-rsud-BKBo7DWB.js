const s="/assets/logo-rsud-D8dyLFCY.png";export{s as _};
